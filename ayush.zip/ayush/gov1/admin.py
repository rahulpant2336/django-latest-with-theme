# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.contrib import admin

from .models import SignUp,Complaint,Suggestion,Feedback,News,Hospital,Medicine

admin.site.register(SignUp)
admin.site.register(Complaint)
admin.site.register(Suggestion)
admin.site.register(Feedback)
admin.site.register(News)
admin.site.register(Hospital)
admin.site.register(Medicine)