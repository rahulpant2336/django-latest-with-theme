from django import forms
from django.contrib.auth.models import User
from .models import Complaint

class ComplaintCreate(forms.ModelForm):
    class Meta:
        model=Complaint
        fields = ['username', 'email','number', 'complaint',]

        labels = {'username': 'UserName',
                  'email':'Email_ID',
                  'number':'Ph_Number',
                  'complaint':'Complaint',}
        widgets={'username':forms.TextInput(attrs={'class':'form-control'}),
                 'email':forms.TextInput(attrs={'class':'form-control'}),
                 'number':forms.TextInput(attrs={'class':'form-control'}),
                 'complaint':forms.TextInput(attrs={'class':'form-control'}),

        }


