from django.contrib.auth.models import Permission, User
from django.db import models
from django.core.urlresolvers import reverse


class SignUp (models.Model):
    user_id = models.CharField(max_length=100)
    username = models.CharField(max_length=100)
    password = models.CharField(max_length=100)
    gender = models.CharField(max_length=100)
    number = models.CharField(max_length=100)
    email = models.CharField(max_length=100)
    location = models.CharField(max_length=100)

    def get_absolute_url(self):
        return reverse('gov1:signup', kwargs={'pk': self.pk})

    def __str__(self):
        return self.user_id


class Complaint(models.Model):
    username = models.CharField(max_length=100)
    email= models.CharField(max_length=100)
    number = models.IntegerField()
    complaint = models.CharField(max_length=500)

    def get_absolute_url(self):
        return reverse('gov1:complaint',kwargs={'pk':self.pk})


    def __str__(self):
        return self.username


class Suggestion(models.Model):
    username = models.CharField(max_length=100)
    email = models.CharField(max_length=100)
    number = models.CharField(max_length=100)
    suggestion = models.CharField(max_length=500)

    def get_absolute_url(self):
        return reverse('gov1:suggestion',kwargs={'pk':self.pk})

    def __str__(self):
        return self.username



class Feedback(models.Model):
    usernames = models.CharField(max_length=30)
    emailids = models.CharField(max_length=50)
    contactnos = models.CharField(max_length=20)
    rating = models.CharField(max_length=4)
    feedbacks = models.CharField(max_length=100)

    def get_absolute_url(self):
        return reverse('gov1:feedback',kwargs={'pk':self.pk})

    def __str__(self):
        return self.usernames

class News(models.Model):
    dates = models.CharField(max_length=30)
    topic = models.CharField(max_length=50)
    description = models.CharField(max_length=100)
    location = models.CharField(max_length=100)

class Hospital(models.Model):
    hospitalname = models.CharField(max_length=30)
    address = models.CharField(max_length=50)
    emailids = models.CharField(max_length=100)
    contactno = models.CharField(max_length=20)

class Medicine(models.Model):
    symptom1 = models.CharField(max_length=50)
    symptom2 = models.CharField(max_length=50)
    symptom3 = models.CharField(max_length=50)
    medicine1 = models.CharField(max_length=50)
    medicine2 = models.CharField(max_length=20)
    medicine3 = models.CharField(max_length=100)
    doctor1 = models.CharField(max_length=50)
    doctor1address = models.CharField(max_length=100)
    doctor2 = models.CharField(max_length=50)
    doctor2address = models.CharField(max_length=100)

