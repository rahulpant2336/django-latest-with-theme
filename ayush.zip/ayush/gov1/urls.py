from django.conf.urls import url
from . import views
from .views import ComplaintCreate,ComplaintList,ComplaintDelete,ComplaintUpdate,ComplaintShow,SuggestionCreate,FeedbackCreate,SignUpCreate

urlpatterns = [
    # /home/
    url(r'^$', views.home, name='home'),
    url(r'^about/', views.about, name='about'),
   # url(r'^gallery/$', views.gallery, name='gallery'),
    url(r'^complaint/$', ComplaintCreate.as_view(), name='complaint'),
    url(r'^suggestion/$', SuggestionCreate.as_view(), name='suggestion'),
    url(r'^feedback/$', FeedbackCreate.as_view(), name='feedback'),
    url(r'^feedback/$', SignUpCreate.as_view(), name='signup'),
    url(r'^touristplaces/$', views.touristplaces, name='touristplaces'),

    url(r'^gallery/', ComplaintList.as_view(), name='aboutlist'),
    url(r'^hospital/$', views.hospital, name='hospital'),
    url(r'^gallary/$', views.gallary, name='gallary'),

    url(r'^edit/(?P<pk>\d+)/$', ComplaintDelete.as_view(), name='delete'),
    url(r'^delete/(?P<pk>\d+)/$', ComplaintUpdate.as_view(), name='update'),
    url(r'^show/', ComplaintShow.as_view(), name='show'),
]

